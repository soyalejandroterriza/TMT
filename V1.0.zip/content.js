chrome.runtime.onMessage.addListener((msg) => {
    if (msg.action === "toggleBarra") {
        toggleBarra();
    }
});

//Habilitar y deshabilitar barra con comando
function toggleBarra() {
    let barra = document.getElementById("mi-barra-superior");

    if (!barra) {
        barra = document.createElement("div");
        barra.id = "mi-barra-superior";

        Object.assign(barra.style, {
            position: "fixed",
            top: "0",
            right: "0",
            width: "260px",         // ancho fijo
            height: "100vh",        // ocupa toda la altura
            backgroundColor: "black",
            color: "white",
            fontSize: "16px",
            display: "flex",
            flexDirection: "column", // AHORA en vertical
            alignItems: "stretch",
            padding: "10px",
            gap: "10px",
            zIndex: "999999999",
            overflowY: "auto"        // scroll si hace falta
});

        document.documentElement.appendChild(barra);

        // IMPORTANTE → botones solo se crean cuando la barra se crea
        ensureUtilityButtons();

    } else {
    const wasHidden = (barra.style.display === "none");
    barra.style.display = wasHidden ? "flex" : "none";

    // Si estaba oculta y ahora se muestra → limpiamos datos
    if (wasHidden) clean_data();
}
}

//Función para ocultar la barra.
function hide_barra() {
    const barra = document.getElementById("mi-barra-superior");
    if (barra) {
        barra.style.display = "none";
    }
}

// Crear o devolver el contenedor interno donde van los botones
function ensureInnerContainer() {
    let container = document.getElementById("mi-barra-superior-inner");

    if (!container) {
        container = document.createElement("div");
        container.id = "mi-barra-superior-inner";

        Object.assign(container.style, {
            width: "100%",
            display: "flex",
            flexDirection: "column",
            gap: "8px"
});

        const barra = document.getElementById("mi-barra-superior");
        barra.appendChild(container);
    }

    return container;
}

// Crear botón genérico (para GET DATA, CLEAN, HIDE, etc)
function createSimpleButton(text, onClick) {
    const btn = document.createElement("button");

    btn.textContent = text;

    // Estilo para barra lateral
    btn.style.width = "100%";             // ocupa todo el ancho
    btn.style.padding = "8px 10px";       // padding más cómodo
    btn.style.textAlign = "left";         // texto alineado a la izquierda
    btn.style.cursor = "pointer";
    btn.style.background = "#333";        // fondo gris oscuro
    btn.style.color = "white";            // texto blanco
    btn.style.border = "1px solid #555";  // bordecito sutil
    btn.style.borderRadius = "4px";       // esquinas redondeadas
    btn.style.fontSize = "14px";

    // Hover para hacerlo más vistoso (opcional)
    btn.addEventListener("mouseover", () => {
        btn.style.background = "#444";
    });

    btn.addEventListener("mouseout", () => {
        btn.style.background = "#333";
    });

    btn.addEventListener("click", onClick);

    return btn;
}


// Función para limpiar todos los datos atrapados.
function clean_data() {

    const ids = [
        "btn_order_id",
        "btn_state",
        "btn_matricula",
        "btn_km",
        "btn_contact_name",
        "btn_contact_phone",
        "btn_shop_zip",
        "btn_shop_name",
        "btn_obs"
    ];

    ids.forEach(id => {
        const btn = document.getElementById(id);
        if (btn) {
            const short = btn.textContent.split(":")[0]; // OR, ES, MAT, KM, NOM, TEL
            btn.textContent = `${short}: NULO`;
            btn.disabled = true;
        }
    });
}

// Función raiz para GET_DATA
function get_data() {
    const order_id = get_order_id();
    render_order_id(order_id);

    const state = get_state();
    render_state(state);

    const matricula = get_matricula();
    render_matricula(matricula);

    const km = get_kilometros();
    render_kilometros(km);

    const contact_name = get_contact_name();
    render_contact_name(contact_name);

    const contact_phone = get_contact_phone();
    render_contact_phone(contact_phone);

    const shop = get_shop_info();
    render_shop_zip(shop.zip);
    render_shop_name(shop.name);

    const obs = get_obs();
    render_obs(obs);
}



// Funciones RENDER
function render_order_id(value) { //Número de orden Northgate
    let btn = document.getElementById("btn_order_id");

    if (!btn) {
        btn = document.createElement("button");
        btn.id = "btn_order_id";
        btn.style.padding = "6px 10px";

        // Copiar valor al portapapeles
        btn.addEventListener("click", () => {
            if (value) navigator.clipboard.writeText(value);
        });

        const container = ensureInnerContainer();
        container.appendChild(btn);
    }

    btn.textContent = value ? `OR: ${value}` : "OR: NULO";
    btn.disabled = !value;
}
function render_state(value) { //Estado de la orden
    let btn = document.getElementById("btn_state");

    if (!btn) {
        btn = document.createElement("button");
        btn.id = "btn_state";
        btn.style.padding = "6px 10px";

        btn.addEventListener("click", () => {
            if (value) navigator.clipboard.writeText(value);
        });

        const container = ensureInnerContainer();
        container.appendChild(btn);
    }

    btn.textContent = value ? `Estado: ${value}` : "ES: NULO";
    btn.disabled = !value;
}
function render_matricula(value) { //Matrícula
    let btn = document.getElementById("btn_matricula");

    if (!btn) {
        btn = document.createElement("button");
        btn.id = "btn_matricula";
        btn.style.padding = "6px 10px";

        btn.addEventListener("click", () => {
            if (value) navigator.clipboard.writeText(value);
        });

        const container = ensureInnerContainer();
        container.appendChild(btn);
    }

    btn.textContent = value ? `Matricula: ${value}` : "MAT: NULO";
    btn.disabled = !value;
}
function render_kilometros(value) { //Kilómetros
    let btn = document.getElementById("btn_km");

    if (!btn) {
        btn = document.createElement("button");
        btn.id = "btn_km";
        btn.style.padding = "6px 10px";

        btn.addEventListener("click", () => {
            if (value) navigator.clipboard.writeText(value);
        });

        const container = ensureInnerContainer();
        container.appendChild(btn);
    }

    btn.textContent = value ? `KM: ${value}` : "KM: NULO";
    btn.disabled = !value;
}
function render_contact_name(value) { //Nombre del usuario
    let btn = document.getElementById("btn_contact_name");

    if (!btn) {
        btn = document.createElement("button");
        btn.id = "btn_contact_name";
        btn.style.padding = "6px 10px";

        btn.addEventListener("click", () => {
            if (value) navigator.clipboard.writeText(value);
        });

        const container = ensureInnerContainer();
        container.appendChild(btn);
    }

    btn.textContent = value ? `Usuario: ${value}` : "NOM: NULO";
    btn.disabled = !value;
}
function render_contact_phone(value) { //Teléfono del usuario
    let btn = document.getElementById("btn_contact_phone");

    if (!btn) {
        btn = document.createElement("button");
        btn.id = "btn_contact_phone";
        btn.style.padding = "6px 10px";

        btn.addEventListener("click", () => {
            if (value) navigator.clipboard.writeText(value);
        });

        const container = ensureInnerContainer();
        container.appendChild(btn);
    }

    btn.textContent = value ? `Telefono: ${value}` : "TEL: NULO";
    btn.disabled = !value;
}
function render_shop_zip(zip) { //CP Taller
    let btn = document.getElementById("btn_shop_zip");

    if (!btn) {
        btn = document.createElement("button");
        btn.id = "btn_shop_zip";
        btn.style.padding = "6px 10px";

        btn.addEventListener("click", () => {
            if (zip) navigator.clipboard.writeText(zip);
        });

        const container = ensureInnerContainer();
        container.appendChild(btn);
    }

    btn.textContent = zip ? `ZIP: ${zip}` : "ZIP: NULO";
    btn.disabled = !zip;
}
function render_shop_name(name) { //Nombre del taller
    let btn = document.getElementById("btn_shop_name");

    if (!btn) {
        btn = document.createElement("button");
        btn.id = "btn_shop_name";
        btn.style.padding = "6px 10px";

        btn.addEventListener("click", () => {
            if (name) navigator.clipboard.writeText(name);
        });

        const container = ensureInnerContainer();
        container.appendChild(btn);
    }

    btn.textContent = name ? `SHOP: ${name}` : "SHOP: NULO";
    btn.disabled = !name;
}
function render_obs(value) { //Observaciones
    let btn = document.getElementById("btn_obs");

    if (!btn) {
        btn = document.createElement("button");
        btn.id = "btn_obs";
        btn.style.padding = "6px 10px";

        // Copiar al portapapeles
        btn.addEventListener("click", () => {
            if (value) navigator.clipboard.writeText(value);
        });

        const container = ensureInnerContainer();
        container.appendChild(btn);
    }

    btn.textContent = "OBS";
    btn.disabled = !value;
}





// Funciones independientes de atrapar datos
function get_order_id() { //Número de orden Northgate
    const el = document.querySelector(".numParte");
    return el ? el.textContent.trim() : "";
}
function get_state() {  //Estado de la orden
    const el = document.getElementById("estPptoCab");
    return el ? el.textContent.trim() : "";
}
function get_matricula() { //Matrícula
    const el = document.getElementById("matricula");
    return el ? el.value.trim() : "";
}
function get_kilometros() { //Kilómetros
    const el = document.getElementById("kilometros");
    return el ? el.value.trim() : "";
}
function get_contact_name() { //Nombre de contacto
    const el = document.getElementById("nombre_contacto");
    return el ? el.value.trim() : "";
}
function get_contact_phone() { //Telefono del usuario
    const el = document.getElementById("telefono");
    return el ? el.value.trim() : "";
}
function get_shop_info() { //CP y nombre del taller
    const el = document.getElementById("direccion_taller");
    if (!el) return { zip: "", name: "" };

    const text = el.value ? el.value.trim() : el.textContent.trim(); // por si es input o span

    // ZIP = primeros 5 dígitos
    const zipMatch = text.match(/^\d{5}/);
    const zip = zipMatch ? zipMatch[0] : "";

    // NAME = resto del texto, quitando "XXXXX "
    const name = zip ? text.substring(6).trim() : text;

    return { zip, name };
}
function get_obs() { //Observaciones
    const el = document.getElementById("obs_taller");
    if (!el) return "";

    // Puede ser <textarea> o <input> o <div>
    if ("value" in el) return el.value.trim();
    return el.textContent.trim();
}





// Insertar botones GET DATA y CLEAN al cargar la barra
function ensureUtilityButtons() {
    const container = ensureInnerContainer();

    if (!document.getElementById("btn_hide")) {
        const btnHide = createSimpleButton("HIDE", hide_barra);
        btnHide.id = "btn_hide";
        container.appendChild(btnHide);
    }

    if (!document.getElementById("btn_get_data")) {
        const btnGet = createSimpleButton("GET DATA", get_data);
        btnGet.id = "btn_get_data";
        container.appendChild(btnGet);
    }

    if (!document.getElementById("btn_clean")) {
        const btnClean = createSimpleButton("CLEAN", clean_data);
        btnClean.id = "btn_clean";
        container.appendChild(btnClean);
    }
}

